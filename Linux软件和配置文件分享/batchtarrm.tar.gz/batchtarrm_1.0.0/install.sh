#!/bin/bash
set -u
set -e
# Prep 1 - Are we "root"
if [ $UID -eq 0 ]; then
zenity --width=600 --no-wrap --question --title="batchtarrm" --text="Welcome to use batchtarrm software!\n--By WHLN from Suihua University Linux Enthusiast Team (SULET)\n\nPlease read README file at first\nPress Yes To install and No to cancel."
if [ $? == 0 ]; then
cp batch-tar batch-rm /usr/bin
zenity --info \
--width=450 \
--no-wrap \
--title="batchtarrm" \
--text="Installation Completed!\n\n"
exit 0			 
else
echo "installation refused by $USER: `date`"
exit 1
fi
else
echo "Please run as root or use sudo"
exit 1
fi


