一.for循环语法结构
1.列表循环（列表for循环：用于将一组命令执行已知的次数）

基本语法结构
#!/bin/bash
for i in a b c
do
	echo $i
done

#!/bin/bash
for i in {1..10}
do
	echo $i
done

#!/bin/bash
for i in $(seq 10)
do
	echo $i
done

#!/bin/bash
for i in $(seq 1 2 10)		# 设置步长
do
	echo $i
done

2.不带列表循环（不带列表的for循环执行时由用户指定参数和参数的个数）

基本语法结构
for i
do
	command
	command
	...
done

3.类C风格的for循环
基本语法结构
for(( expr1;expr2;expr3 ))
do
	command
	command
	…
done

for (( i=1;i<=5;i++))
do
	echo $i
done

expr1：定义变量并赋初值
expr2：决定是否进行循环（条件）
expr3：决定循环变量如何改变，决定循环什么时候退出

循环控制语句
continue：继续；表示循环体内下面的代码不执行，重新开始下一次循环
break：打断；马上停止执行本次循环，执行循环体后面的代码
exit：表示直接跳出程序

二.脚本用法
先将脚本复制到可执行的位置，建议放到/usr/local/bin/目录，这个目录用来存放用户的可执行文件。
$ cp -r batch-tar batch-rm /usr/local/bin

然后给它执行权限
$ chmod 755 batch-tar batch-rm
切记一点，在网上或其他地方看到的shell脚本一定要先仔细阅读，以防其中包含恶意程序和危险命令，如rm -rf /

for循环也可以在终端输入，不用输入头文件，默认头文件是当前shell，利用for循环可以批量处理一些文件。
例：

1.将当前目录下的所有文件以tar.gz格式压缩
for f in *; do tar -czvf $f.tar.gz $f; done

2.解压当前目录下的所有文件
for f in *; do tar -xzvf *; done

3.删除当前目录下的所有文件，但不删除包含txt字符串的文件
for f in *; do if [[ ! $f =~ "txt" ]]; rm $f; fi; done


batch-tar脚本的用法
batch-tar [tar命令参数] [文件] [归档格式]

例：
batch-tar -czvf * tar.gz
将当前目录下的所有文件以tar.gz格式压缩

batch-tar -xzvf *
解压当前目录下的所有文件


batch-rm脚本用法
batch-rm [文件] [不包含文件的字符串]

例：删除当前目录下的所有文件，但不删除包含txt字符串的文件
batch-rm * txt

这个脚本可以实现基本功能，但是仍然存在一些缺点，比如遇到带空格的文件会自动断开，因为shell默认的IFS分隔符中就包含空格。
修改IFS我尝试过，去掉空格分隔符之后，多个文件会变成一个整体，之后我会考虑用数组修改一下。
欢迎大家批评指教！

安装方法: 运行"sudo install.sh"即可
卸载方法: 运行"sudo uninstall.sh"即可
