#!/bin/bash
set -u
set -e
# Prep 1 - Are we "root"
if [ $UID -eq 0 ]; then
zenity --width=600 --no-wrap --question --title="batchtarrm" --text="Do you really want to uninstall batchtarrm\n\nPress Yes to uninstall and No to cancel."
if [ $? == 0 ]; then
rm /usr/bin/batch-tar
rm /usr/bin/batch-rm
zenity --info \
--width=450 \
--no-wrap \
--title="batchtarrm" \
--text="Batchtarrm is removed from your computer\n\n"
exit 0                   
else
echo "uninstallation refused by $USER: `date`"
exit 1
fi
else
echo "Please run as root or use sudo"
exit 1
fi

