# Arch Linux Grub主题美化



### 主题美化后的Grub引导

![arch-grub-theme](https://img-blog.csdnimg.cn/4ba548dea95a48e4853e489fca5a9797.jpeg)





### 美化指南

* 1.解压 `arch-grub-theme.tar.gz`之后进入`arch-grub-theme`文件夹

* 2.将`archlinux`主题文件夹移至`/boot/grub/themes/`下

```
$ sudo cp -r archlinux /boot/grub/themes
```

* 3.安装`os-prober`软件

电脑开机时，`os-prober`会自动检测各个硬盘上的其他操作系统，在开机时会有一个引导选择界面，确保系统已经安装os-prober软件。

* 4.更改Grub配置文件

```
$ sudo vim /etc/default/grub
```

取消以下配置的注释

```
GRUB_TIMEOUT_STYLE=menu
```

```
GRUB_TERMINAL_INPUT=console
```

```
GRUB_GFXMODE=auto
```

```
GRUB_GFXPAYLOAD_LINUX=keep
```

```
GRUB_DISABLE_RECOVERY=true
```

```
GRUB_DISABLE_OS_PROBER=false
```

更改`GRUB_THEME`行

```
GRUB_THEME="/usr/share/grub/themes/archlinux/theme.txt"
```

结果如下图：

![arch-grub-cfg](https://img-blog.csdnimg.cn/1c33edc7ddc04311b31d476572f7f459.png)

更新Grub配置

```
$ sudo grub-mkconfig -o /boot/grub/grub.cfg
```

 重启即可看见效果啦