# Grub 引导选择界面美化-主题修改



## 美化指南

我们可以通过更改Grub配置文件`/etc/default/grub`，来定制自己的引导界面。



### 背景图片修改

* 1.准备好背景图片（最好选择适合显示器分辨率的图），移入`/usr/share/grub`文件夹，此文件夹存放grub主题等资源文件

```
$ sudo mv YourImg.* /usr/share/grub
```

* 2.更改Grub配置文件

```
$ sudo vim /etc/default/grub
```

 结果如下图：

![[Grub-Background]](https://img-blog.csdnimg.cn/77912745583c4f86afbfcf099e04c6ad.png)

更改其中`GRUB_BACKGROUND`行

```
GRUB_BACKGROUND="/usr/share/grub/YourImg.*"
```

更新Grub配置

Arch Linux发行版：

```
$ grub-mkconfig -o /boot/grub/grub.cfg
```

Debian发行版：

```
$ sudo update-grub
```



重启即可看见效果啦



### 主题修改

* 1.准备好主题文件夹，可以在[Grub Themes](https://www.gnome-look.org/browse/cat/109/ord/latest/)挑选下载

* 2.将主题文件夹移至`/boot/grub/themes/`下

```
$ sudo mv -r YourTheme /boot/grub/themes
```

* 3.更改Grub配置文件

注释掉`GRUB_BACKGROUND`行

```
#GRUB_BACKGROUND="/usr/share/grub/YourImg.*"
```

更改`GRUB_THEME`行

```
GRUB_THEME="/usr/share/grub/themes/YourTheme/theme.txt"
```

更新Grub配置

```
$ sudo grub-mkconfig -o /boot/grub/grub.cfg
```

 重启即可看见效果啦

* 4.如果对主题字体、排版等一些细节不满意，可以通过编辑主题`theme.txt`文件，进行调整

注：在`Grub Themes`下载的主题压缩包，其中一部分有安装脚本`install.sh`，解压后，进入主题文件夹，执行`sudo ./install.sh`即可配置成功，等效于上述的步骤。



### 主题推荐

- [Blur](https://www.gnome-look.org/p/1220920/)

  ![[Blur]](https://img-blog.csdnimg.cn/ad86cd5a44fb4e9286bb909232e85ae2.png)

  

- [Vimix](https://www.gnome-look.org/p/1009236/)

  ![[Vimix]](https://img-blog.csdnimg.cn/594739a93b7944b0b5bc4fbd620dd9ef.jpeg)

  

- [Stylishdark](https://www.gnome-look.org/p/1009237/)

  ![[Stylishdark]](https://img-blog.csdnimg.cn/78828d84fdbb47439036a76729d99f8c.jpeg)

  

### Grub-Customizer

其实还有一个更方便的软件`Grub-Customizer`，可以直接修改Grub启动项和外观等配置，而且是GUI程序哦，界面如下图：

![[Grub-Customizer]](https://img-blog.csdnimg.cn/6498056045f740369ef808ac7c9c5798.png)

Arch Linux可通过以下命令安装：

```
$ sudo pacman -S grub-customizer 
```



### Grub 开启引导选择界面

* 1.安装`os-prober`软件

  电脑开机时，`os-prober`会自动检测各个硬盘上的其他操作系统，在开机时会有一个引导选择界面，确保系统已经安装os-prober软件。

* 2.更改Grub配置文件

```
$ sudo vim /etc/default/grub
```

 结果如下图：

![[GRUB-DISABLE-OS]](https://img-blog.csdnimg.cn/ebac411e8ec14966a5eaa2cad1837aca.png)

更改其中`#GRUB_DISABLE_OS_PROBER=false `行，取消注释

```
GRUB_DISABLE_OS_PROBER=false 
```

* 3.更新Grub配置

```
$ grub-mkconfig -o /boot/grub/grub.cfg
```

重启即可看见效果啦！

