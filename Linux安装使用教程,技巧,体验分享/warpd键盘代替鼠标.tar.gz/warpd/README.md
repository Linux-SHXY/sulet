# 快速入门

1. 运行 `warpd`

## 提示模式

1. 按下 `A-M-x` (`alt+meta+x`) 生成提示列表
2. 输入与所需目标相关的按键序列，将指针定位到该位置并进入正常模式。
3. 使用正常模式移动按键选择最终目的地（详见正常模式）。

## 网格模式

1. 按下 `A-M-g`（meta 是命令键）以激活定位过程。
2. 使用 `u`, `i`, `j`, `k` 反复导航到不同象限。
3. 按下 `m` 进行左键点击，`,` 进行中键点击或 `.` 进行右键点击。
4. 见正常模式。

## 正常模式

1. 按下 `A-M-c` 以激活正常模式。
2. 使用正常移动按键（默认为 `hjkl`）调整光标。
3. 按下 `m` 进行左键点击，`,` 进行中键点击或 `.` 进行右键点击。
4. 按下 `escape` 退出。

可以从上述任何模式模拟拖动动作，方法是将焦点放在源上，然后按下 `drag_key`(默认为 `v`)，这将引起正常模式用于选择拖动目标。

更全面的说明可以在[手册页面](https://github.com/rvaiya/warpd/blob/master/warpd.1.md)中找到（以及选项列表）。

## Wayland

*注意：*Wayland 不允许客户端全局绑定热键。必须使用 warpd 的单次执行标志在组合器内绑定它们。

例如：

在 sway 上：

```
bindsym Mod4+Mod1+x exec warpd --hint
bindsym Mod4+Mod1+c exec warpd --normal
bindsym Mod4+Mod1+g exec warpd --grid
```

项目地址:https://github.com/rvaiya/warpd